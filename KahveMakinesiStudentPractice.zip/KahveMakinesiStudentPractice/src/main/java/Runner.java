import frontend.SiparisUI;

public class Runner {
    public static void main(String[] args) {
        SiparisUI siparis = new SiparisUI();
        siparis.siparisAl();
    }
}
